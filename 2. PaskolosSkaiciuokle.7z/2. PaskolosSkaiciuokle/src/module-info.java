module PaskolosSkaiciuokle {
    requires java.desktop;
    requires jfreechart;
    requires jcommon;
}
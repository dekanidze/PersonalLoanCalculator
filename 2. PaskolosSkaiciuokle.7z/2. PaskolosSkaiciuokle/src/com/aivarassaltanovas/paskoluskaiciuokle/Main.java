package com.aivarassaltanovas.paskoluskaiciuokle;

import javax.swing.*;

/**
 * Aivaras Šaltanovas
 * Paskolos skaičiuoklė
 * 1.0.1 versija
 */
public class Main extends GUI {

    public static void main(String[] args){

        SwingUtilities.invokeLater(Main::new);

    }
}